# simple-website

#### For testing lamp stack

* Database Name: simple-website
* RootPassWord: 1234

##### Container Created: 
* webserver
* database
* db_dashboard

The Site Has not been made by the user, it is purely used for learning purposes.

Note: There is no need to run the bash script. A simple docker-compose up -d would do.
